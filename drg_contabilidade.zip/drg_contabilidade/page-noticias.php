<?php
// Template Name: Noticias
?>

<?php get_header(); ?>

<section class="noticias">
    <h1 class="h1-noticias">Noticias</h1>
    <div class="container">
        <div class="destaque">
            <div class="notice">
                <div class="thumbnail"></div>
                <div class="notice-content">
                    <h2 class="notice-subtitle">noerfe</h2>
                    <h3 class="notice-title">dfdfvwd cxwefc erbjnunj kmuk</h3>
                </div>
            </div>
        </div>
        <div class="links">
            <div class="notice">
                <div class="thumbnail"></div>
                <h2 class="notice-subtitle">sdfbnukn</h2>
                <p class="notice-title">xsfvfjujn uikmukjnbvcdr fxsefxsevbni</p>
            </div>
            <div class="notice">
                <div class="thumbnail"></div>
                <h2 class="notice-subtitle">sdfbnukn</h2>
                <p class="notice-title">xsfvf jujnuikmukjnbvcdrf xsefxsevbni</p>
            </div>
            <div class="notice">
                <div class="thumbnail"></div>
                <h2 class="notice-subtitle">sdfbnukn</h2>
                <p class="notice-title">xsfvfjujnu ikmukjnb vcdrfx sefxsevbni</p>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>