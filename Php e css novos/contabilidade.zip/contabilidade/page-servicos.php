<?php
// Template Name: Servicos
?>

<?php get_header(); ?>

<section class="servicos">
    <div class="container">
        <section class="first-services">
            <div class="title-services">
                <h1><?php the_field('titulo_servico'); ?></h1>
            </div>
            <div class="description-one">
                <h3><?php the_field('subtitulo_servico'); ?>
                </h3>
            </div>
        </section>
        <section class="second-services">
            <div class="list-services">
                <h2><?php the_field('lista_servico_um'); ?></h2>
                <ul>
                    <li><?php the_field('servico_um'); ?></li>
                    <li><?php the_field('servico_dois'); ?>o</li>
                    <li><?php the_field('lista_servico_tres'); ?></li>
                    <li><?php the_field('lista_servico_quatro'); ?></li>
                    <li><?php the_field('lista_servico_cinco'); ?></li>
                    <li><?php the_field('lista_servico_seis'); ?></li>
                    <li><?php the_field('lista_servico_sete'); ?></li>
                </ul>
            </div>
            <div class="list-services">
                <h2><?php the_field('lista_servico_dois'); ?></h2>
                <ul>
                    <li><?php the_field('lista_servico_oito'); ?></li>
                    <li><?php the_field('lista_servico_nove'); ?></li>
                    <li><?php the_field('lista_servico_dez'); ?></li>
                    <li><?php the_field('lista_servico_onze'); ?></li>
                    <li><?php the_field('lista_servico_doze'); ?></li>
                    <li><?php the_field('lista_servico_treze); ?></li>
                </ul>
            </div>
            <div class="list-services"">
                <h2><?php the_field('lista_servico_tres'); ?></h2>
                <ul>
                    <li><?php the_field('lista_servico_quatorze'); ?></li>
                    <li><?php the_field('lista_servico_quinze'); ?></li>
                    <li><?php the_field('lista_servico_dezesseis'); ?></li>
                    <li><?php the_field('lista_servico_dezessete'); ?></li>
                    <li><?php the_field('lista_servico_dezoito'); ?></li>
                </ul>
            </div>
        </section>
    </div>
</section>

<?php get_footer(); ?>